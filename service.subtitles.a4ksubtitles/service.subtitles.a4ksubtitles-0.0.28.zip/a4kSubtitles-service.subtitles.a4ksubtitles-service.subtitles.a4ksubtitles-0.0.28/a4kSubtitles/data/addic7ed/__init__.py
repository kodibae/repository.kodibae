# -*- coding: utf-8 -*-

from a4kSubtitles.lib import utils

languages = utils.get_relative_json(__file__, 'languages')
tvshows = utils.get_relative_json(__file__, 'tvshows')
