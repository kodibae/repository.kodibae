# -*- coding: utf-8 -*-

import sys
from a4kSubtitles import core

if __name__ == '__main__':
    core.main(sys.argv[2][1:])
